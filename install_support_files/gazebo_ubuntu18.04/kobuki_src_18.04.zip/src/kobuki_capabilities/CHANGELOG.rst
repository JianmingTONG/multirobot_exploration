^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kobuki_capabilities
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.6 (2015-05-27)
------------------

0.6.5 (2014-11-21)
------------------

0.6.4 (2014-08-26)
------------------

0.6.3 (2014-08-25)
------------------
* rename kobuki_apps as kobuki_rapps to resolve `#336 <https://github.com/yujinrobot/kobuki/issues/336>`_
* Contributors: Jihoon Lee

0.6.2 (2014-08-11)
------------------

0.6.1 (2014-08-08)
------------------
* sync with current app manager launcher. default kobuki capabilities param file added
* Contributors: Jihoon Lee

0.6.0 (2014-08-08)
------------------
* moves app manager launcher to kobuki_capabilities (solves `#331 <https://github.com/yujinrobot/kobuki/issues/331>`_)
* kobuki_capabilities: adds nodelet manager support for bringup provider
* updates and extends kobuki's capabilities
* adds cleanup and updates for the recent changes in capabilities dev
* kobuki_capabilities: adds provider specific remappings and fixes
  semantic interface remappings
* adds an initial set of kobuki-specific interfaces and providers plus idle node
* adds kobuki_capabilities
* Contributors: Jihoon Lee, Marcus Liebhardt

* moves app manager launcher to kobuki_capabilities (solves `#331 <https://github.com/yujinrobot/kobuki/issues/331>`_)
* kobuki_capabilities: adds nodelet manager support for bringup provider
* updates and extends kobuki's capabilities
* adds cleanup and updates for the recent changes in capabilities dev
* kobuki_capabilities: adds provider specific remappings and fixes
  semantic interface remappings
* adds an initial set of kobuki-specific interfaces and providers plus idle node
* adds kobuki_capabilities
* Contributors: Marcus Liebhardt

0.5.6 (2014-05-23)
------------------

0.5.5 (2013-10-11)
------------------

0.5.4 (2013-09-11)
------------------

0.5.3 (2013-08-30 12:30)
------------------------

0.5.2 (2013-08-30 01:44)
------------------------

0.5.1 (2013-08-30 01:43)
------------------------

0.5.0 (2013-08-29)
------------------

0.4.0 (2013-08-09)
------------------

0.3.9 (2013-06-04)
------------------

0.3.8 (2013-05-22)
------------------

0.3.7 (2013-04-16)
------------------

0.3.6 (2013-02-28)
------------------

0.3.5 (2013-02-19)
------------------

0.3.4 (2013-02-10 13:29)
------------------------

0.3.3 (2013-02-10 00:19)
------------------------

0.3.2 (2013-02-08 23:31)
------------------------

0.3.1 (2013-02-08 17:28)
------------------------

0.2.4 (2013-01-21)
------------------

0.2.3 (2013-01-16)
------------------

0.2.2 (2013-01-02)
------------------

0.2.1 (2012-12-22)
------------------

0.2.0 (2012-12-21 19:37)
------------------------

0.1.9 (2012-12-21 19:35)
------------------------

0.1.8 (2012-12-10)
------------------

0.1.7 (2012-12-05)
------------------

0.1.5 (2012-11-22)
------------------

0.1.4 (2012-11-21)
------------------

0.1.3 (2012-11-16)
------------------

0.1.2 (2012-11-03)
------------------

0.1.1 (2012-11-05)
------------------

0.1.0 (2012-04-20)
------------------
